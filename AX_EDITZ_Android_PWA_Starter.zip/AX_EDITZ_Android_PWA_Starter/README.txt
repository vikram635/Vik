AX EDITZ Android PWA Starter

WHAT THIS IS
A PWA-ready package built around the available AX EDITZ index.html source. It is not a signed APK or Android App Bundle (.aab).

MOBILE DEPLOYMENT
1. Open https://github.com/vikram635/Vik on your phone and sign in.
2. Download a backup of the current repository before changing anything.
3. Upload/replace index.html and add manifest.json, sw.js, icon.svg, icon-192.png, and icon-512.png in the repository root. Keep existing images/assets folders.
4. Commit changes, then open https://vikram635.github.io/Vik/ in Chrome.
5. Open Chrome menu > Add to Home screen / Install app. Test online first, then airplane mode.

LIMITS / HONEST TEST STATUS
- Package file/manifest checks are performed; this does not prove the app works on your phone.
- The service worker caches the app shell and same-origin resources as they are visited. It cannot make Supabase login/signup or external CDN libraries work offline automatically.
- Existing editor uses browser MediaRecorder/canvas APIs; trim accuracy, export playback and offline export need real Android testing.
- Project save code uses localStorage and notes that the video file must be selected again.
- For Play Store, generate an Android package (for example with PWABuilder), configure Digital Asset Links, test the Android build, sign it, and complete Google Play Console requirements.
- Do not overwrite your live site until you have a backup and are ready to test.
